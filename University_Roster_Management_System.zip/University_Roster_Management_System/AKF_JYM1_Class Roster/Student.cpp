#include <iostream>
#include "student.h"

//Set Default values for constructor
Student::Student() {


	this->studentID = "";
	this->firstName = "";
	this->lastName = "";
	this->emailAddress = "";
	this->age = 0;
	this->studentProgram = DegreeProgram::SOFTWARE;
	for (int i = 0; i < DaysInCourseLength; i++) {
		this->courseCompletionArray[i] = 0;
	}
}

Student::Student(std::string StudentID, std::string firstName, std::string lastName, std::string emailAddress, int age, double courseCompletionArray[], DegreeProgram studentProgram)
{
	this->studentID = StudentID;
	this->firstName = firstName;
	this->lastName = lastName;
	this->emailAddress = emailAddress;
	this->age = age;
	this->studentProgram = studentProgram;
	for (int i = 0; i < DaysInCourseLength; i++) {
		this->courseCompletionArray[i] = courseCompletionArray[i];
	};
}
//Destructor
Student::~Student()
{
}





//Pull values
std::string Student::pullStudentID() { return this->studentID; }
std::string Student::pullFirstName() { return this->firstName; }
std::string Student::pullLastName() { return this->lastName; }
std::string Student::pullEmailAddress() { return  this->emailAddress; }
int  Student::pullAge() { return  this->age; }
DegreeProgram  Student::pullStudentProgram() { return this->studentProgram; }
double* Student::pullDaysInCourseLength() { return this->courseCompletionArray; }



//Mutator values

void Student::pushStudentID(std::string studentID) { this->studentID = studentID; }
void Student::pushFirstName(std::string  firstName) { this->firstName = firstName; }
void Student::pushLastName(std::string lastName) { this->lastName = lastName; }
void Student::pushEmailAddress(std::string emailAddress) { this->emailAddress = emailAddress; }
void Student::pushAge(int age) { this->age = age; }
void Student::pushCourseCompletionArray(double courseCompletionArray[])
{
	for (int i = 0; i < DaysInCourseLength; i++) 
		this->courseCompletionArray[i] = courseCompletionArray[i];
}
void Student::pushStudentProgram(DegreeProgram degreeprogram) { this->studentProgram = degreeprogram; }


void Student::printHeader() {
	std::cout << "Student ID | First Name | Last Name | Email | Age | Days in Course | Degree Program " << std::endl;
}

//Print Student Values
void Student::print() {

	std::cout << this->studentID << '\t';
	std::cout << this->firstName << '\t';
	std::cout << this->lastName << '\t';
	std::cout << this->emailAddress << '\t';
	std::cout << this->age << '\t';
	std::cout << this->courseCompletionArray[0] << ',';
	std::cout << this->courseCompletionArray[1] << ',';
	std::cout << this->courseCompletionArray[2] << '\t';
	std::cout << DegreeProgramsAvailable[(int)(this->pullStudentProgram())] << std::endl;
}




















