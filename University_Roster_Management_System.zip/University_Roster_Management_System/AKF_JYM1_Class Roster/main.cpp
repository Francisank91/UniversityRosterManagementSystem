#include <iostream>
#include "roster.h"
int main() {

	const std::string studentData[] ={ "A1,John,Smith,John1989@gm ail.com,20,30,35,40,SECURITY", "A2,Suzan,Erickson,Erickson_1990@gmailcom,19,50,30,40,NETWORK", "A3,Jack,Napoli,The_lawyer99yahoo.com,19,20,40,33,SOFTWARE", "A4,Erin,Black,Erin.black@comcast.net,22,50,58,40,SECURITY", "A5,Anthony,Francis,afra243@wgu.edu,30,18,22,30,SOFTWARE" };


	const int numStudentRecords = 5;
	Roster Roster;
	//PrintAll
	for (int i = 0; i < numStudentRecords; i++) Roster.parse(studentData[i]);
	std::cout << "All Enrolled Students: " << std::endl;
	Roster.printAll();
	std::cout << std::endl;


	//Print Invalid Addresses
	std::cout << "Invalid Email Addresses: " << std::endl;
	Roster.printInvalidEmails();
	std::cout << std::endl;

	//Print by Program
	for (int i = 0; i < 3; i++)
	{

		std::cout << "Students by Program: " << DegreeProgramsAvailable[i] << std::endl;
		Roster.printPrograms((DegreeProgram)i);

	}




	//Print Average of Course Days
	std::cout << "Average Days to completion: " << std::endl;
	Roster.printAverageDaysInCourse("A5");
	std::cout << std::endl;

	//Expelling Student A3
	std::cout << "Expelling Student A3: " << std::endl << std::endl;
	Roster.remove("A3");
	std::cout << std::endl << std::endl;


	//Expelling Student A3 Again
	std::cout << "Expelling Student A3 2: " << std::endl << std::endl;
	Roster.remove("A3");
	std::cout << std::endl << std::endl;



	//Expelling Student A3 Again
	std::cout << "Clear Student Memory:" << std::endl;
	Roster.destructRoster();
	std::cout << std::endl << std::endl;

	//F2.Anthony Francis
	std::cout << "Roster Class Instance:" << std::endl << std::endl;
	std::cout << "Course Title:" << " Scripting and Programming - Applications" << std::endl;
	std::cout << "Programming Language Used:" << " C++" << std::endl;
	std::cout << "WGU Student ID:" << "#001189788" << std::endl;
	std::cout << "Student Name:" << "Anthony Francis" << std::endl << std::endl;



	system("pause");
	return 0;

	};