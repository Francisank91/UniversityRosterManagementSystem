#pragma once
#include "student.h"


//E.

class Roster
{
private:
	int lastIndex = -1;
	const static int numStudentRecords = 5;
	Student* classRosterArray[numStudentRecords];

public:
	void parse(std::string row);
	//set instance variables
	void add(std::string studentID, std::string firstName, std::string lastName, std::string emailAddress, int age, double daysInCourse1, double daysInCourse2, double daysInCourse3, DegreeProgram degreeprogram);
//removes students
	void remove(std::string studentID);
	//prints table
	void printAll();
	//prints degree programs
	void printPrograms(DegreeProgram degreeprogram);
	//print average number of days
	void printAverageDaysInCourse(std::string studentID);
	//print bad emails
	void printInvalidEmails();
	void destructRoster();
};