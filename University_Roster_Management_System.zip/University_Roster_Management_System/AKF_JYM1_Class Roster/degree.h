#pragma once
#include <string>

//C. Define Enumerated Data type
enum class DegreeProgram { SECURITY, NETWORK, SOFTWARE };
static const std::string DegreeProgramsAvailable[] = { "SECURITY","NETWORK","SOFTWARE" };