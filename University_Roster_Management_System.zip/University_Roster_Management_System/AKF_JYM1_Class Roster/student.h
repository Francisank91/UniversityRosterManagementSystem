#pragma once
#include "degree.h"
#include <iostream>
#include <iomanip>



class Student {
public:
	const static int DaysInCourseLength = 3;
private:
	//D1. Student Variables
	
	std::string studentID;
	std::string firstName;
	std::string lastName;
	std::string emailAddress;
	int age;
	double courseCompletionArray[DaysInCourseLength];
	DegreeProgram studentProgram;

public:
	//Student Constructor
	Student();
	Student(std::string StudentID, std::string firstName, std::string lastName, std::string emailAddress, int age, double courseCompletionArray[], DegreeProgram studentProgram);
	// Student Destructor
	~Student();





	//D2. Student Fucntions
	//Accessors (getters)
	std::string pullStudentID();
	std::string pullFirstName();
	std::string pullLastName();
	std::string pullEmailAddress();
	int pullAge();
	double* pullDaysInCourseLength();
	DegreeProgram pullStudentProgram();

	//Mutators (setters)
	void pushStudentID(std::string studentID);
	void pushFirstName(std::string firstName);
	void pushLastName(std::string lastName);
	void pushEmailAddress(std::string emailAddress);
	void pushAge(int age);
	void pushCourseCompletionArray(double courseCompletionArray[]);
	void pushStudentProgram(DegreeProgram degreeprogram);

	//Print Student Data---
	static void printHeader();
	void print();












};

