#include <iostream>
#include "roster.h"



//Parse student data rows
void Roster::parse(std::string studentData)
{
	
	DegreeProgram degreeprogram = DegreeProgram::SOFTWARE;
	if (studentData.back() == 'K') degreeprogram = DegreeProgram::NETWORK;
	else if (studentData.back() == 'Y') degreeprogram = DegreeProgram::SECURITY;

	int searchRight = studentData.find(",");
	std::string studentID = studentData.substr(0, searchRight);

	//Parse First Name
	int searchLeft = searchRight + 1;
	searchRight = studentData.find(",", searchLeft);
	std::string firstName = studentData.substr(searchLeft, searchRight - searchLeft);
	
	//Parse Last Name
	searchLeft = searchRight + 1;
	searchRight = studentData.find(",", searchLeft);
	std::string lastName = studentData.substr(searchLeft, searchRight - searchLeft);

	//Parse Email Address
	searchLeft = searchRight + 1;
	searchRight = studentData.find(",", searchLeft);
	std::string emailAddress = studentData.substr(searchLeft, searchRight - searchLeft);

	//Parse Age
	searchLeft = searchRight + 1;
	searchRight = studentData.find(",", searchLeft);
	auto age = stod(studentData.substr(searchLeft, searchRight - searchLeft));

	//Parse Days in Course and convert to int
	searchLeft = searchRight + 1;
	searchRight = studentData.find(",", searchLeft);
	double daysInCourse1 = stod(studentData.substr(searchLeft, searchRight - searchLeft));

	searchLeft = searchRight + 1;
	searchRight = studentData.find(",", searchLeft);
	double daysInCourse2 = stod(studentData.substr(searchLeft, searchRight - searchLeft));

	searchLeft = searchRight + 1;
	searchRight = studentData.find(",", searchLeft);
	double daysInCourse3 = stod(studentData.substr(searchLeft, searchRight - searchLeft));




	add(studentID, firstName, lastName,  emailAddress,  age, daysInCourse1, daysInCourse2,  daysInCourse3, degreeprogram);


}

void Roster::add(std::string studentID, std::string firstName, std::string lastName, std::string emailAddress, int age, double daysInCourse1, double daysInCourse2, double daysInCourse3, DegreeProgram degreeprogram)
{	//new avg completion array
	double parseArray[3] = { daysInCourse1 ,daysInCourse2 ,daysInCourse3 };

	classRosterArray[++lastIndex] = new Student(studentID,  firstName, lastName, emailAddress,  age, parseArray, degreeprogram);


}


void Roster::printAll()
{
	Student::printHeader();
	for (int i = 0; i <= Roster::lastIndex; i++) {

		classRosterArray[i]->print();


	}


}
//Print by program type
void Roster::printPrograms(DegreeProgram degreeprogram)
{

	Student::printHeader();
	for (int i = 0; i <= Roster::lastIndex; i++) {

		if (Roster::classRosterArray[i]->pullStudentProgram() == degreeprogram) classRosterArray[i]->print();
	}

	std::cout << std::endl;

}

//Print Average Days
void Roster::printAverageDaysInCourse(std::string studentID)
{
	for (int i = 0; i <= Roster::lastIndex; i++)
	{
		
		if(classRosterArray[i]->pullStudentID() == studentID){
		
			std::cout << classRosterArray[i]->pullStudentID() << ": ";
			std::cout << (classRosterArray[i]->pullDaysInCourseLength()[0]
				+ classRosterArray[i]->pullDaysInCourseLength()[1]
				+ classRosterArray[i]->pullDaysInCourseLength()[2]) / 3.0 << std::endl;		
		}
					
	}

	std::cout << std::endl;

}





//Invalid emails printed
void Roster::printInvalidEmails()
{

	bool any = false;
	for (int i = 0; i <= Roster::lastIndex; i++)
	{
		std::string emailAddress = (classRosterArray[i]->pullEmailAddress());
		if (emailAddress.find('@') == std::string::npos || emailAddress.find(' ') != std::string::npos || emailAddress.find('.') == std::string::npos)
		{
			any = true;
			std::cout << classRosterArray[i]->pullStudentID() << ":  " << classRosterArray[i]->pullEmailAddress() << std::endl;
		}
				
	}
	if (!any) std::cout << "NONE" << std::endl;


}

//Remove Student A3
void Roster::remove(std::string studentID)
{
	bool success = false;
	int dialog = 0;
	for (int i = 0; i <= Roster::lastIndex; i++)
	{
		if(dialog <= 2)
		{
		
			if (classRosterArray[i]->pullStudentID() == studentID)//removal
			{
				success = true;
				if (i < numStudentRecords - 1)
				{
					Student* temp = classRosterArray[i];
					classRosterArray[i] = classRosterArray[numStudentRecords - 1];
					classRosterArray[numStudentRecords - 1] = temp;
				}

				Roster::lastIndex--;
			
			}
			if (success)//Removal confirmation
			{
				std::cout << studentID << "Record has been deleted." << std::endl << std::endl;
				this->printAll();
				std::cout << std::endl << std::endl;
				dialog++;
				break;
			}
			else if (classRosterArray[i]->pullStudentID() != studentID)
			{

					dialog++;
			}
		


		}



	}
	if (dialog > 2 && success == false)
	{
		std::cout << "Such a student with this ID was not found" << std::endl << std::endl;
		std::cout << std::endl << std::endl;
	}


}


void Roster::destructRoster()
{
	Roster::~Roster();
	{
		std::cout << "Roster has been destroyed." << std::endl << std::endl;
		for (int i = 0; i < numStudentRecords; i++)
		{
			std::cout << "Expelled Student Record # " << i + 1 << std::endl;
			delete classRosterArray[i];
			classRosterArray[i] = nullptr;




		}




	}
}






